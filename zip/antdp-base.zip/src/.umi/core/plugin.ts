// @ts-nocheck
import { Plugin } from '/home/runner/work/antdp/antdp/node_modules/@umijs/runtime';

const plugin = new Plugin({
  validKeys: ['modifyClientRenderOpts','patchRoutes','rootContainer','render','onRouteChange','__mfsu','dva','request','locale',],
});

export { plugin };
