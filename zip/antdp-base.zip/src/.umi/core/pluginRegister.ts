// @ts-nocheck
import { plugin } from './plugin';
import * as Plugin_0 from '/home/runner/work/antdp/antdp/examples/antdp-base/src/.umi/plugin-dva/runtime.tsx';
import * as Plugin_1 from '/home/runner/work/antdp/antdp/examples/antdp-base/src/.umi/plugin-locale/runtime.tsx';
import * as Plugin_2 from '@@/plugin-antd-icon-config/app.ts';

  plugin.register({
    apply: Plugin_0,
    path: '/home/runner/work/antdp/antdp/examples/antdp-base/src/.umi/plugin-dva/runtime.tsx',
  });
  plugin.register({
    apply: Plugin_1,
    path: '/home/runner/work/antdp/antdp/examples/antdp-base/src/.umi/plugin-locale/runtime.tsx',
  });
  plugin.register({
    apply: Plugin_2,
    path: '@@/plugin-antd-icon-config/app.ts',
  });

export const __mfsu = 1;
