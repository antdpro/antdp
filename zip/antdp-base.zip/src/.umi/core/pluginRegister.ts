// @ts-nocheck
import { plugin } from './plugin';
import * as Plugin_0 from '../plugin-locale/runtime.tsx';
import * as Plugin_1 from '../plugin-model/runtime';
import * as Plugin_2 from '@@/plugin-antd-icon-config/app.ts';

  plugin.register({
    apply: Plugin_0,
    path: '../plugin-locale/runtime.tsx',
  });
  plugin.register({
    apply: Plugin_1,
    path: '../plugin-model/runtime',
  });
  plugin.register({
    apply: Plugin_2,
    path: '@@/plugin-antd-icon-config/app.ts',
  });

export const __mfsu = 1;
