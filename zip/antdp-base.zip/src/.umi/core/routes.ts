// @ts-nocheck
import React from 'react';
import { ApplyPluginsType, dynamic } from '/home/runner/work/antdp/antdp/node_modules/@umijs/runtime';
import * as umiExports from './umiExports';
import { plugin } from './plugin';
import LoadingComponent from '@/components/PageLoading/index';

export function getRoutes() {
  const routes = [
  {
    "path": "/login",
    "component": dynamic({ loader: () => import(/* webpackChunkName: 'layouts__UserLayout' */'@/layouts/UserLayout'), loading: LoadingComponent}),
    "exact": true
  },
  {
    "path": "/",
    "component": dynamic({ loader: () => import(/* webpackChunkName: 'layouts__BasicLayout' */'@/layouts/BasicLayout'), loading: LoadingComponent}),
    "routes": [
      {
        "path": "/",
        "redirect": "/welcome",
        "exact": true
      },
      {
        "path": "/welcome",
        "name": "首页",
        "icon": "welcome",
        "locale": "welcome",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Home__index' */'@/pages/Home/index'), loading: LoadingComponent}),
        "exact": true
      },
      {
        "path": "/dashboard",
        "name": "Dashboard",
        "icon": "dashboard",
        "locale": "dashboard",
        "routes": [
          {
            "path": "/dashboard/demo",
            "name": "组件demo",
            "locale": "组件demo",
            "icon": "pie-chart",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Demo' */'@/pages/Demo'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/dashboard/workplace",
            "name": "工作台",
            "locale": "工作台",
            "icon": "pie-chart",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Dashboard__Workplace' */'@/pages/Dashboard/Workplace'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/dashboard/analysis",
            "name": "分析页",
            "icon": "bar-chart",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Setting__User' */'@/pages/Setting/User'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/dashboard/monitor",
            "name": "监控台",
            "icon": "radar-chart",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Setting__User' */'@/pages/Setting/User'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/dashboard/notfund",
            "name": "测试不存在页面",
            "icon": "radar-chart",
            "exact": true
          }
        ]
      },
      {
        "path": "/router",
        "name": "测试路由参数",
        "icon": "dashboard",
        "routes": [
          {
            "path": "/router/list",
            "name": "路由页面",
            "icon": "pie-chart",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Router__List' */'@/pages/Router/List'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/router/list/:id/detail",
            "name": "路由详情页面",
            "icon": "pie-chart",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Router__Detail' */'@/pages/Router/Detail'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/router/state",
            "name": "路由传递参数",
            "icon": "pie-chart",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Router__State' */'@/pages/Router/State'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/router/state/detail",
            "name": "路由传递参数-详情",
            "icon": "pie-chart",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Router__State__Detail' */'@/pages/Router/State/Detail'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "path": "/profile",
        "name": "详情页",
        "icon": "profile",
        "routes": [
          {
            "name": "基础",
            "icon": "file-jpg",
            "routes": [
              {
                "path": "/profile/demo1",
                "name": "详情页1",
                "icon": "file-zip",
                "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Dashboard__Workplace' */'@/pages/Dashboard/Workplace'), loading: LoadingComponent}),
                "exact": true
              },
              {
                "path": "/profile/demo2",
                "name": "详情页2",
                "icon": "file-sync",
                "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Dashboard__Workplace' */'@/pages/Dashboard/Workplace'), loading: LoadingComponent}),
                "exact": true
              }
            ]
          },
          {
            "path": "/profile/advanced",
            "name": "高级详情页",
            "icon": "file-protect",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Setting__User' */'@/pages/Setting/User'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "path": "/setting",
        "name": "设置页面",
        "icon": "setting",
        "routes": [
          {
            "path": "/setting/basic",
            "name": "用户设置",
            "icon": "file-jpg",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Setting__User' */'@/pages/Setting/User'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/setting/advanced",
            "name": "参数设置",
            "icon": "file-protect",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Setting__Advanced' */'@/pages/Setting/Advanced'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "path": "/404",
        "name": "404",
        "hideInMenu": true,
        "icon": "file-protect",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'@/pages/404'), loading: LoadingComponent}),
        "exact": true
      },
      {
        "path": "/403",
        "name": "403",
        "hideInMenu": true,
        "icon": "file-protect",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__403' */'@/pages/403'), loading: LoadingComponent}),
        "exact": true
      },
      {
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'@/pages/404'), loading: LoadingComponent})
      }
    ]
  }
];

  // allow user to extend routes
  plugin.applyPlugins({
    key: 'patchRoutes',
    type: ApplyPluginsType.event,
    args: { routes },
  });

  return routes;
}
