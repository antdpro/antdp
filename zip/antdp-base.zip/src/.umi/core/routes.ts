// @ts-nocheck
import React from 'react';
import { ApplyPluginsType, dynamic } from '/home/runner/work/antdp/antdp/node_modules/@umijs/runtime';
import * as umiExports from './umiExports';
import { plugin } from './plugin';
import LoadingComponent from '@/components/PageLoading/index';

export function getRoutes() {
  const routes = [
  {
    "path": "/login",
    "component": dynamic({ loader: () => import(/* webpackChunkName: 'layouts__UserLayout' */'@/layouts/UserLayout'), loading: LoadingComponent}),
    "exact": true
  },
  {
    "path": "/",
    "component": dynamic({ loader: () => import(/* webpackChunkName: 'layouts__BasicLayout' */'@/layouts/BasicLayout'), loading: LoadingComponent}),
    "routes": [
      {
        "path": "/",
        "redirect": "/welcome",
        "exact": true
      },
      {
        "path": "/welcome",
        "name": "首页",
        "icon": "welcome",
        "locale": "welcome",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Home__index' */'@/pages/Home/index'), loading: LoadingComponent}),
        "exact": true
      },
      {
        "path": "/dashboard",
        "name": "实例展示",
        "icon": "dashboard",
        "locale": "dashboard",
        "side": true,
        "routes": [
          {
            "path": "/dashboard/demo",
            "name": "实例展示1",
            "locale": "实例展示1",
            "icon": "pie-chart",
            "index": true,
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Demo' */'@/pages/Demo'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/dashboard/workplace",
            "name": "工作台1",
            "locale": "工作台1",
            "icon": "pie-chart",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Dashboard' */'@/pages/Dashboard'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/dashboard/notfund",
            "name": "测试不存在页面1",
            "hideInMenu": true,
            "icon": "radar-chart",
            "exact": true
          }
        ]
      },
      {
        "path": "/EditTable",
        "name": "编辑表格",
        "icon": "file-protect",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__EditTable' */'@/pages/EditTable'), loading: LoadingComponent}),
        "routes": [
          {
            "path": "/EditTable/demo",
            "name": "实例展示2",
            "locale": "实例展示2",
            "icon": "pie-chart",
            "index": true,
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Demo' */'@/pages/Demo'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/EditTable/workplace",
            "name": "工作台2",
            "locale": "工作台2",
            "hideInMenu": true,
            "icon": "pie-chart",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Dashboard' */'@/pages/Dashboard'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/EditTable/notfund",
            "name": "测试不存在页面2",
            "icon": "radar-chart",
            "exact": true
          }
        ]
      },
      {
        "path": "/EditTables",
        "name": "编辑表格2",
        "icon": "file-protect",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__EditTable' */'@/pages/EditTable'), loading: LoadingComponent}),
        "exact": true
      },
      {
        "path": "/EditTabless",
        "name": "编辑表格3",
        "icon": "file-protect",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__EditTable' */'@/pages/EditTable'), loading: LoadingComponent}),
        "exact": true
      },
      {
        "path": "/EditTable1",
        "name": "编辑表格",
        "icon": "file-protect",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__EditTable' */'@/pages/EditTable'), loading: LoadingComponent}),
        "exact": true
      },
      {
        "path": "/EditTables2",
        "name": "编辑表格2",
        "icon": "file-protect",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__EditTable' */'@/pages/EditTable'), loading: LoadingComponent}),
        "exact": true
      },
      {
        "path": "/EditTabless3",
        "name": "编辑表格3",
        "icon": "file-protect",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__EditTable' */'@/pages/EditTable'), loading: LoadingComponent}),
        "exact": true
      },
      {
        "path": "/EditTable4",
        "name": "编辑表格",
        "icon": "file-protect",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__EditTable' */'@/pages/EditTable'), loading: LoadingComponent}),
        "exact": true
      },
      {
        "path": "/EditTables5",
        "name": "编辑表格2",
        "icon": "file-protect",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__EditTable' */'@/pages/EditTable'), loading: LoadingComponent}),
        "exact": true
      },
      {
        "path": "/EditTabless6",
        "name": "编辑表格3",
        "icon": "file-protect",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__EditTable' */'@/pages/EditTable'), loading: LoadingComponent}),
        "exact": true
      },
      {
        "path": "/404",
        "name": "404",
        "hideInMenu": true,
        "icon": "file-protect",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'@/pages/404'), loading: LoadingComponent}),
        "exact": true
      },
      {
        "path": "/403",
        "name": "403",
        "hideInMenu": true,
        "icon": "file-protect",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__403' */'@/pages/403'), loading: LoadingComponent}),
        "exact": true
      },
      {
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'@/pages/404'), loading: LoadingComponent})
      }
    ]
  }
];

  // allow user to extend routes
  plugin.applyPlugins({
    key: 'patchRoutes',
    type: ApplyPluginsType.event,
    args: { routes },
  });

  return routes;
}
