// @ts-nocheck

import DashboardOutlined from '@ant-design/icons/DashboardOutlined';
import PieChartOutlined from '@ant-design/icons/PieChartOutlined';
import RadarChartOutlined from '@ant-design/icons/RadarChartOutlined';
import FileProtectOutlined from '@ant-design/icons/FileProtectOutlined'

export default {
  DashboardOutlined,
PieChartOutlined,
RadarChartOutlined,
FileProtectOutlined
}
    