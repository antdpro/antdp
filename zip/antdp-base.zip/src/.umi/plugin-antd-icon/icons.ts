// @ts-nocheck

import DashboardOutlined from '@ant-design/icons/DashboardOutlined';
import PieChartOutlined from '@ant-design/icons/PieChartOutlined';
import BarChartOutlined from '@ant-design/icons/BarChartOutlined';
import RadarChartOutlined from '@ant-design/icons/RadarChartOutlined';
import ProfileOutlined from '@ant-design/icons/ProfileOutlined';
import FileJpgOutlined from '@ant-design/icons/FileJpgOutlined';
import FileZipOutlined from '@ant-design/icons/FileZipOutlined';
import FileSyncOutlined from '@ant-design/icons/FileSyncOutlined';
import FileProtectOutlined from '@ant-design/icons/FileProtectOutlined';
import SettingOutlined from '@ant-design/icons/SettingOutlined'

export default {
  DashboardOutlined,
PieChartOutlined,
BarChartOutlined,
RadarChartOutlined,
ProfileOutlined,
FileJpgOutlined,
FileZipOutlined,
FileSyncOutlined,
FileProtectOutlined,
SettingOutlined
}
    