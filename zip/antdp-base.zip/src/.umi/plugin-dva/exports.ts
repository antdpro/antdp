// @ts-nocheck

export { connect, useDispatch, useStore, useSelector } from '/home/runner/work/antdp/antdp/node_modules/dva';
export { getApp as getDvaApp } from './dva';
