import React from 'react';
import PageLoading from '@antdp/page-loading';

// loading components from code split
// https://umijs.org/plugin/umi-plugin-react.html#dynamicimport
export default () => <PageLoading />;
