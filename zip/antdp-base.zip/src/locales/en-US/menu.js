export default {
  'menu.welcome': 'Welcome',
  'menu.home': 'home',
  'menu.dashboard': 'dashboard',
  'menu.404': '404',
  'menu.403': '403',
};
