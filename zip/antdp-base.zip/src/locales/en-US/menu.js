export default {
  'menu.welcome': 'Welcome',
  'menu.home': 'home',
  'menu.dashboard': 'dashboard',
  'menu.dashboard.工作台': 'workbench',
  'menu.dashboard.分析页': 'Analysis page',
  'menu.dashboard.监控台': 'Monitoring station',
  'menu.dashboard.测试不存在页面': 'Test page undefined',

  'menu.测试路由参数': 'Routing parameters',
  'menu.测试路由参数.路由页面': 'Routing page',
  'menu.测试路由参数.路由详情页面': 'Routing details page',
  'menu.测试路由参数.路由传递参数': 'Routing parameters',
  'menu.测试路由参数.路由传递参数-详情': 'Routing parameters-details',

  'menu.详情页': 'Details page',
  'menu.详情页.基础': 'Basics',
  'menu.详情页.基础.详情页1': 'Details page 1',
  'menu.详情页.基础.详情页2': 'Details page 2',
  'menu.详情页.高级详情页': 'Advanced details page',

  'menu.设置页面': 'Setup page',
  'menu.设置页面.用户设置': 'User settings',
  'menu.设置页面.参数设置': 'Parameter setting',

  'menu.404': '404',
  'menu.403': '403',
};
