export default {
  'menu.welcome': 'Welcome To AntdP',
  'menu.home': 'home',
  'menu.dashboard': 'dashboard',
  'menu.dashboard': 'welcome',
  'menu.dashboard.实例展示': 'Demo Page',
  'menu.dashboard.工作台': 'workbench',
  'menu.dashboard.测试不存在页面': 'Test page undefined',

  'menu.404': '404',
  'menu.403': '403',
};
