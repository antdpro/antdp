export default {
  'menu.welcome': '欢迎1',
  'menu.home': '首页',
  'menu.dashboard': '首页1',
  'menu.dashboard.组件demo': '组件demo',
  'menu.dashboard.工作台': '工作台',
  'menu.dashboard.分析页': '分析页',
  'menu.dashboard.监控台': '监控台',
  'menu.dashboard.测试不存在页面': '测试不存在页面',

  'menu.测试路由参数': '测试路由参数',
  'menu.测试路由参数.路由页面': '路由页面',
  'menu.测试路由参数.路由详情页面': '路由详情页面',
  'menu.测试路由参数.路由传递参数': '路由传递参数',
  'menu.测试路由参数.路由传递参数-详情': '路由传递参数-详情',

  'menu.详情页': '详情页',
  'menu.详情页.基础': '基础',
  'menu.详情页.基础.详情页1': '详情页1',
  'menu.详情页.基础.详情页2': '详情页2',
  'menu.详情页.高级详情页': '高级详情页',

  'menu.设置页面': '设置页面',
  'menu.设置页面.用户设置': '用户设置',
  'menu.设置页面.参数设置': '参数设置',

  'menu.404': '404',
  'menu.403': '403',
};
