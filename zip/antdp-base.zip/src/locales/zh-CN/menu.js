export default {
  'menu.welcome': '欢迎',
  'menu.home': '首页',
  'menu.dashboard': '实例展示',
  'menu.404': '404',
  'menu.403': '403',
};
