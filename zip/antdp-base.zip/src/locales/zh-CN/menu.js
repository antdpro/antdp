export default {
  'menu.welcome': '欢迎来到antdp',
  'menu.home': '首页',
  'menu.dashboard': '实例展示',
  'menu.dashboard.实例展示': '实例展示',
  'menu.dashboard.工作台': '工作台',
  'menu.dashboard.测试不存在页面': '测试不存在页面',

  'menu.404': '404',
  'menu.403': '403',
};
