export const detailItems = [
  {
    label: '仓库名',
    name: 'remark',
    type: 'input',
    initialValue: 'uiw',
  },
  {
    label: '仓库域名',
    name: 'remark',
    type: 'input',
    initialValue: '@nihao.com',
  },
  {
    label: '仓库域名',
    name: 'remark',
    type: 'input',
    initialValue: 'nihao',
  },
  {
    label: '仓库管理员',
    name: 'remark',
    type: 'input',
    initialValue: 'xx',
  },
  {
    label: '审批人',
    name: 'remark',
    type: 'input',
    initialValue: 'xx',
  },
  {
    label: '生效日期',
    name: 'remark',
    type: 'input',
    initialValue: '2023-4-27',
  },
  {
    label: '仓库类型',
    name: 'remark',
    type: 'input',
    initialValue: '私有',
  },
];

export const userItems = [
  {
    label: '任务名',
    name: 'remark',
    type: 'input',
    initialValue: 'uiw',
  },
  {
    label: '任务描述',
    name: 'remark',
    type: 'input',
    initialValue: '@nihao.com',
  },
  {
    label: '执行人',
    name: 'remark',
    type: 'input',
    initialValue: 'nihao',
  },
  {
    label: '责任人',
    name: 'remark',
    type: 'input',
    initialValue: 'xx',
  },
  {
    label: '生效日期',
    name: 'remark',
    type: 'input',
    initialValue: 'xx',
  },
  {
    label: '任务类型',
    name: 'remark',
    type: 'input',
    initialValue: '私有',
  },
];
