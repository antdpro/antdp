import React, { PureComponent } from 'react';

export default class NotLogged extends PureComponent {
  render() {
    return <div>404</div>;
  }
}
