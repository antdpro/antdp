export const applyItems = [
  {
    title: 'Alipay',
    maxNum: '18',
    minNum: '1303',
  },
  {
    title: 'Alipay',
    maxNum: '18',
    minNum: '1303',
  },
  {
    title: 'Alipay',
    maxNum: '18',
    minNum: '1303',
  },
  {
    title: 'Alipay',
    maxNum: '18',
    minNum: '1303',
  },
  {
    title: 'Alipay',
    maxNum: '18',
    minNum: '1303',
  },
  {
    title: 'Alipay',
    maxNum: '18',
    minNum: '1303',
  },
  {
    title: 'Alipay',
    maxNum: '18',
    minNum: '1303',
  },
  {
    title: 'Alipay',
    maxNum: '18',
    minNum: '1303',
  },
];

export const cardItems = [
  {
    title: 'Alipay',
    content: '那是一种内在的东西， 他们到达不了，也无法触及的',
    time: '几秒前',
  },
  {
    title: 'Alipay',
    content: '那是一种内在的东西， 他们到达不了，也无法触及的',
    time: '2 小时前',
  },
  {
    title: 'Alipay',
    content: '那是一种内在的东西， 他们到达不了，也无法触及的',
    time: '2 小时前',
  },
  {
    title: 'Alipay',
    content: '那是一种内在的东西， 他们到达不了，也无法触及的',
    time: '2 小时前',
  },
  {
    title: 'Alipay',
    content: '那是一种内在的东西， 他们到达不了，也无法触及的',
    time: '2 小时前',
  },
  {
    title: 'Alipay',
    content: '那是一种内在的东西， 他们到达不了，也无法触及的',
    time: '2 小时前',
  },
  {
    title: 'Alipay',
    content: '那是一种内在的东西， 他们到达不了，也无法触及的',
    time: '2 小时前',
  },
  {
    title: 'Alipay',
    content: '那是一种内在的东西， 他们到达不了，也无法触及的',
    time: '2 小时前',
  },
];

export const listItems = [
  {
    title: 'Alipay',
    content:
      '段落示意：蚂蚁金服设计平台 ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。蚂蚁金服设计平台 ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。',
    time: '2023-04-27 13:50',
    labels: ['Ant Design', '设计语言'],
    name: '付小小 ',
    star: 169,
    good: 114,
    mess: 16,
  },
  {
    title: 'Alipay',
    content:
      '段落示意：蚂蚁金服设计平台 ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。蚂蚁金服设计平台 ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。',
    time: '2023-04-27 13:50',
    labels: ['Ant Design', '设计语言'],
    name: '付小小 ',
    star: 169,
    good: 114,
    mess: 16,
  },
  {
    title: 'Alipay',
    content:
      '段落示意：蚂蚁金服设计平台 ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。蚂蚁金服设计平台 ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。',
    time: '2023-04-27 13:50',
    labels: ['Ant Design', '设计语言'],
    name: '付小小 ',
    star: 169,
    good: 114,
    mess: 16,
  },
  {
    title: 'Alipay',
    content:
      '段落示意：蚂蚁金服设计平台 ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。蚂蚁金服设计平台 ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。',
    time: '2023-04-27 13:50',
    labels: ['Ant Design', '设计语言'],
    name: '付小小 ',
    star: 169,
    good: 114,
    mess: 16,
  },
  {
    title: 'Alipay',
    content:
      '段落示意：蚂蚁金服设计平台 ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。蚂蚁金服设计平台 ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。',
    time: '2023-04-27 13:50',
    labels: ['Ant Design', '设计语言'],
    name: '付小小 ',
    star: 169,
    good: 114,
    mess: 16,
  },
  {
    title: 'Alipay',
    content:
      '段落示意：蚂蚁金服设计平台 ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。蚂蚁金服设计平台 ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。',
    time: '2023-04-27 13:50',
    labels: ['Ant Design', '设计语言'],
    name: '付小小 ',
    star: 169,
    good: 114,
    mess: 16,
  },
  {
    title: 'Alipay',
    content:
      '段落示意：蚂蚁金服设计平台 ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。蚂蚁金服设计平台 ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。',
    time: '2023-04-27 13:50',
    labels: ['Ant Design', '设计语言'],
    name: '付小小 ',
    star: 169,
    good: 114,
    mess: 16,
  },
  {
    title: 'Alipay',
    content:
      '段落示意：蚂蚁金服设计平台 ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。蚂蚁金服设计平台 ant.design，用最小的工作量，无缝接入蚂蚁金服生态，提供跨越设计与开发的体验解决方案。',
    time: '2023-04-27 13:50',
    labels: ['Ant Design', '设计语言'],
    name: '付小小 ',
    star: 169,
    good: 114,
    mess: 16,
  },
];
